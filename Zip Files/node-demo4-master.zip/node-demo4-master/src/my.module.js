const list = [
  { id: 1, city: "Mumbai", maxTemp: 32, minTemp: 24 },
  { id: 2, city: "Delhi", maxTemp: 30, minTemp: 26 },
  { id: 3, city: "Kolkata", maxTemp: 32, minTemp: 25 },
  { id: 4, city: "Chennai", maxTemp: 34, minTemp: 26 },
  { id: 5, city: "Chennai", maxTemp: 34, minTemp: 26 },
];

module.exports = { list };
