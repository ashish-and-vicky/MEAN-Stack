const dbread = require("./db.read");
const dbadd = require("./db.add");

dbread.readUserByQueryParams(1, "onkar@gmail.com");
