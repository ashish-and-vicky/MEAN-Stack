const DB_CONFIG = {
  host: "192.168.64.5",
  user: "mysql",
  password: "mysql",
  database: "DAC2020",
};

module.exports = { DB_CONFIG };
