# Hello Angular - Google Product

- Client Side
- Mobile App / Desktop / Web App as well.
- Framework
- SPA
- Modularity (Module/Component)
- Typescript :: Javascript
- Component

# Keep in your Mind

- Javascript
- Typescript = (Javascript + DataType)
- NodeJS (Server Side)
- ExpressJS (Server Side)
- Angular (Client)

```
int n = 10;
let n = 10;
```
