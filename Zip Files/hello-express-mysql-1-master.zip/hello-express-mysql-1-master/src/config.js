const DB_CONFIG = {
  user: "mysql",
  password: "mysql",
  host: "192.168.64.5",
  database: "DAC2020",
};

module.exports = { DB_CONFIG };
