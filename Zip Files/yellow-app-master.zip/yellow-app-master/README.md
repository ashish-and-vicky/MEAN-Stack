# YellowApp

- To Add Font Awsome Module

```
ng add @fortawesome/angular-fontawesome@0.7
```
