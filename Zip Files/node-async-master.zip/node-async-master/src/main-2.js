let hello = () => {
  console.log("Hello World");
  return 1234;
};

let output = hello();
console.log(output);
