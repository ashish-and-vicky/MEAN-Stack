// Named Annonymous Function
let helloWorld = function () {
  for (let i = 0; i < 10; i++) {
    console.log("I am annonymous function!!");
  }
  console.log("I AM DONE!!");
};

// Arrow Function
let helloUniverse = () => {
  console.log("I am arrow function!!!");
};

helloWorld();
helloUniverse();
