let sum = (n1, n2) => {
  return n1 + n2;
};

let diff = (n1, n2) => {
  return n1 - n2;
};

let multiply = (n1, n2) => {
  return n1 * n2;
};

let divide = (n1, n2) => {
  return n1 / n2;
};

module.exports = {
  sum,
  diff,
  multiply,
  divide,
};
