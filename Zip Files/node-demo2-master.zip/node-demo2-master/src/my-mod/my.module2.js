const APP_NAME = "NODJE_JS";

const AREA = 1000;
const PI = 3.14159;

const TITLE = "Hello World";

// NAMED EXPORT :: THE NAME CAN BE SAME OR DIFFERENT
module.exports.MY_APP_NAME = APP_NAME;
module.exports.MY_AREA = AREA;
module.exports.PI = PI;
