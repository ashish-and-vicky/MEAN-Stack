```
/**
 * Module
 * Package [N P(Package/Module/Library) M]
 * Library
 *
 * #include stdio.h;  // C, C++
 *
 * java.lang.*;       // JAVA
 * java.util.*;
 */

/**
 * Node JS :: Module
 * How module works in NodeJS (Server. Its not available in Client Side WHY?).
 *
 * Types of Module (ReUsable Program)
 *  Local Module
 *  Internal Module
 *  External Module
 */
```
