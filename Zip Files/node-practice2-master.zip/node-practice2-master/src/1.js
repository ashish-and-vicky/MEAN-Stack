let json = {
    title:'CDAC',
    name:'Akshay'
}

console.log(json);