function hello() {

}

function world () {

}


hello();