console.log('EXECUTION START AT LINE 1');

class Main {

    static main() {
     console.log("Hello World Like Java!!");   
    }

}


Main.main();